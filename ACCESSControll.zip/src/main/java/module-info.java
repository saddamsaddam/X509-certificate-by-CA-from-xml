module info{
    requires org.bouncycastle.provider;

    requires java.xml;
    requires org.bouncycastle.pkix;
    requires java.desktop;
    requires org.apache.poi.poi;
    requires org.apache.poi.ooxml;
    requires swingx;
}